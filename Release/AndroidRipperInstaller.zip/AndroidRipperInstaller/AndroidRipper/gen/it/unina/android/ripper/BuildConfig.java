/** Automatically generated file. DO NOT MODIFY */
package it.unina.android.ripper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}