package it.unina.android.ripper.extractor;

import it.unina.android.ripper.model.ActivityDescription;

public interface IExtractor
{
	public ActivityDescription extract();
}
