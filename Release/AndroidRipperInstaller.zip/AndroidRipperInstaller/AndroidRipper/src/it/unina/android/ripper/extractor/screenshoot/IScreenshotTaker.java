package it.unina.android.ripper.extractor.screenshoot;

import android.app.Activity;

public interface IScreenshotTaker
{
	public void takeScreenshot(Activity activity);
}
