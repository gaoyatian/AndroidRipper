package it.unina.android.ripper.configuration;

public interface IConfiguration {

}
